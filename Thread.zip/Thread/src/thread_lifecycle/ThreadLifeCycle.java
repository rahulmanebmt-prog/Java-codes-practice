package thread_lifecycle;
/*
New state : Thread in this state when it's created but not yet started
Runnable : After that it may switch to Runnable state where it can be running,
			or ready to run when it get's calls CPU time. 
			
Running : When it get's cpu time it will move to running state.
Blocked/Waiting state: Thread is in this state when it's waiting for resource,
						or another thread to complete it's execution.

Terminated : A thread is in this state when it's finished, it's execution.

*/


public class ThreadLifeCycle extends Thread{
	
	
	@Override
	public void run() {
		System.out.println("RUNNING");
		try {
			Thread.sleep(2000);				// Here we can't use Throws declaration because run() is overridden also we are telling to wait for 2 sec 
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws InterruptedException {
		
		ThreadLifeCycle t1 = new ThreadLifeCycle(); // New state -> here is new state thread is created but not yet started
		System.out.println(t1.getState());
		
		t1.start(); // Runnable state
		System.out.println(t1.getState());
		
		Thread.sleep(100);
		System.out.println(t1.getState()); // TIMED_WAITING -> In run() we used Thread.sleep(200) so it will tell t1 to wait for 2 seconds 
		
		t1.join(); // here we are telling main() to wait for completion of t1 thread
		System.out.println(t1.getState());

	}

}
