package WaysOfCreatingThread;

/*
 * 1st way of creating thread is by extending Thread class.
 * By extending thread class we can create thread and we can execute,
 * by creating object of that class and we can call obj_name.start() method
 */

class Example1 extends Thread{

	@Override
	public void run() {
		for( ; ; )
		{
			System.out.println("World");
		}
	}
	
	
	
}

public class ExtendingTreadClass{
	
	public static void main(String[] args) {
		
		Example1 ex1 = new Example1();
		ex1.start();
		
		for( ; ; )
		{
			System.out.println("Hello");
		}

	}

}
