package WaysOfCreatingThread;

/*
 2nd way to create thread is implementing Runnable Interface
 for that we need implement Runnable interface and we need to create object of implementing class
 that object need to pass to constructor of thread class as shown below:
	 Thread t1 = new Thread(obj);
 */

class Example2 implements Runnable{

	@Override
	public void run() {
		for( ; ; ) {
			System.out.println("World");
		}
		
	}
	
}

public class ByImplementingRunnableInterface {

	public static void main(String[] args) {
		
		Example2 ex2 = new Example2();
		Thread t1 = new Thread(ex2);
		t1.start();
		
		for( ; ; ) {
			System.out.println("Hello");
		}
		
	}

}
