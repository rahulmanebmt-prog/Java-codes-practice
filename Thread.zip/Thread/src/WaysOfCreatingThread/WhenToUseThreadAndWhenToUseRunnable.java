package WaysOfCreatingThread;

class B{
	void b() {
		System.out.println(" B");
	}
}

/*
class A extends B, Thread{		//if a class extends any class so we can't extend Thread class
								// becuase of multiple inheritance, so in that case use Runnable.
	
}
*/

class A extends B implements Runnable{

	@Override
	public void run() {
		
		for( ; ; )
		{
			System.out.println("World");
		}
		
	}
	
}


public class WhenToUseThreadAndWhenToUseRunnable {

	public static void main(String[] args) {
		
		A a = new A();
		a.run();
		
		for( ; ; )
		{
			System.out.println("Hello");
		}
		
		

	}

}
