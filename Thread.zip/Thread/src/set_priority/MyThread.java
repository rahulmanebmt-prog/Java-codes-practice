package set_priority;

public class MyThread extends Thread{
	
	public MyThread(String name) {  // here we can provide name by calling constructor of class which extends Thread class.
		super(name); // we need to provide name to Thread class constructor using super();
	}
	
	@Override
	public void run() {
		for(int i=0; i<5; i++) {
			System.out.println(Thread.currentThread().getName()+ " -priority: " +Thread.currentThread().getPriority() + " -count" + i);
			
			try {
				Thread.sleep(100);
				
			}catch(Exception e) {
				
			}	
		}
	}

	public static void main(String[] args) {
		
		// Here we created 3 thread
		MyThread l = new MyThread("Low Priority");
		MyThread m = new MyThread("Mid Priority");
		MyThread h = new MyThread("High Priority");
	/*	
		 Here we are setting priorities to Threads
		 It is not strict rules that first this need to done but it will give hint to JVM.
		 In single core processor it will be noticable but we are using multi core processor so they may work parallely,
		 so it will be not noticable
	*/	 
		l.setPriority(MIN_PRIORITY); 
		m.setPriority(NORM_PRIORITY); 
		h.setPriority(MAX_PRIORITY);
		
		// Here we are starting threads
		l.start();
		m.start();
		h.start();

	}

}
