package main_thread;

// main thread: Each program has at least one thread i.e main thread
// main thread starts the execution of program

public class MainThread {

	public static void main(String[] args) {
		
		System.out.println("Hello");
		

		Thread t = Thread.currentThread();

        System.out.println("Thread Name: " + t.getName());
        System.out.println("Thread State: " + t.getState());
        System.out.println("Thread Priority: " + t.getPriority());
        System.out.println("Thread Is Alive: " + t.isAlive());
        

	}

}
