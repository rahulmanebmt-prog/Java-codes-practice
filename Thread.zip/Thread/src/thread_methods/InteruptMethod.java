package thread_methods;

public class InteruptMethod extends Thread{
	
	@Override
	public void run() {
		
		try {
			Thread.sleep(100);
			System.out.println(" t1 Thread is Running...");
			
		} catch (InterruptedException e) {
			System.out.println(" t2 Thread Interupted..." +e);
		}
	}

	public static void main(String[] args) {
		
		InteruptMethod t1 = new InteruptMethod();
		t1.start();
		
		InteruptMethod t2 = new InteruptMethod();
		t2.start();
		t2.interrupt(); // It will stop the thread whatever it's doing for ex. t2 was trying to sleep,
						// but here we interupted or stopped t2 thread by t2.interrupt();
		
		

	}

}
