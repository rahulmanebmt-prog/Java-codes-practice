package thread_methods;

/*
 Daeman thread is low priority thread that works in a back ground 
 JVM not wait for daemon thread to complete it's execution as soon as user thread and main thread
 completes it's execution JVM will terminate and it will not wait for daemon thread to complete it's execution
 */

public class DaemanThread extends Thread{

	
	@Override
	public void run() {
		while(true)
		{
			System.out.println("Running user thread..");
		}
	}

	public static void main(String[] args) {
		
		DaemanThread myThread = new DaemanThread();
		myThread.setDaemon(true);
		myThread.start();
		System.out.println("Main");// here main thread completes it's execution so jvm will wait for main to complete it's execution
									// till then daemon thread works even jvm not waits for it's completion but daemon threads gets some time
									// until thread execution completion after it's done jvm will not wait for completion of daemon so it's terminated
		

	}

}
