package thread_methods;

/*
Tells the scheduler:

“I am willing to pause and let other threads execute”

🔍 Important Behavior of Thread.yield()
🚨 Yield is only a hint, NOT a command

JVM may ignore yield()
Thread may continue running

Behavior depends on:
JVM implementation
OS thread scheduler
System load

✅ So your output is NON-deterministic
Example outputs may vary:

Thread 1.. is Running
Thread 2.. is Running
Thread 1.. is Running
Thread 1.. is Running
Thread 2.. is Running

or even:
Thread 1.. is Running (5 times)
Thread 2.. is Running (5 times)
👉 Both are valid


⚠️ Important Things to Know (Interview Gold)
1️⃣ Yield does NOT:
❌ Pause the thread
❌ Guarantee another thread runs
❌ Release locks
❌ Work like sleep()

2️⃣ Yield only affects threads of same priority
If one thread has higher priority:

yield() may have no effect

*/


public class YieldMethod extends Thread{
	
	public YieldMethod(String name) {
		super(name);
	}
	
	@Override
	public void run() {
		for(int i=0; i<5; i++) {
			System.out.println(Thread.currentThread().getName()+ " is Running");
			Thread.yield(); // Here we are telling JVM to yield means we are giving hint that
							// there are other threads also and it can give chance to execute them also.
		}
		
	}

	public static void main(String[] args) {
		
		YieldMethod t1 = new YieldMethod("Thread 1..");
		YieldMethod t2 = new YieldMethod("Thread 2..");
		t1.start();
		t2.start();

	}

}
