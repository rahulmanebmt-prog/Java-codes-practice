/**
 * 
 */
/**
 * 
 */
module design_patterns_in_java {
}