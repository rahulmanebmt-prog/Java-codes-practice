package singletone_design_pattern;

import java.lang.reflect.Constructor;

public class Soln1_for_brk_singleT {
	
private static Soln1_for_brk_singleT s;
	
	private Soln1_for_brk_singleT() {
		
		if(s!=null)
		{
			throw new RuntimeException("You are trying to break singletone pattern");
		}
		
	}
	
	public static  Soln1_for_brk_singleT getInstnce() {
		if(s==null)
			synchronized(Soln1_for_brk_singleT.class)
			{
				if(s==null) {
					s = new Soln1_for_brk_singleT();
				}
			}
		{
			
		}
		return s;
		
	}

}


class Main2{
	public static void main(String[] args) throws Exception {
		
		Soln1_for_brk_singleT sp1 = Soln1_for_brk_singleT.getInstnce();
		System.out.println(sp1.hashCode());
		
		Constructor<Soln1_for_brk_singleT> constructor = Soln1_for_brk_singleT.class.getDeclaredConstructor();
		constructor.setAccessible(true);  // here we are modifying dynamically
		Soln1_for_brk_singleT sp2 = constructor.newInstance();
		System.out.println(sp2.hashCode());
	}
}

