package singletone_design_pattern;

public class SingletonDP {
	private static SingletonDP s;
	
	private SingletonDP() {
		
	}
	
	public static  SingletonDP getInstnce() {
		if(s==null)
			synchronized(SingletonDP.class)
			{
				if(s==null) {
					s = new SingletonDP();
				}
			}
		{
			
		}
		return s;
		
	}

}



class Main{
	public static void main(String[] args) {
		
		System.out.println(SingletonDP.getInstnce().hashCode());
	}
}
