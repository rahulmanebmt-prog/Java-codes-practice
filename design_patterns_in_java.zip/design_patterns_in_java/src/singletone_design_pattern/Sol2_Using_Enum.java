package singletone_design_pattern;

import java.lang.reflect.Constructor;

public enum Sol2_Using_Enum {
	
	INSTANCE;
	
	public void test() {
		System.out.println("It's working");
	}
	

}


class Main3{
	public static void main(String[] args) throws Exception {
		
		Sol2_Using_Enum instance = Sol2_Using_Enum.INSTANCE;
		System.out.println(instance.hashCode());
		instance.test();
		
		Constructor<Sol2_Using_Enum> constructor = Sol2_Using_Enum.class.getDeclaredConstructor();
		constructor.setAccessible(true);  // here we are modifying dynamically
		Sol2_Using_Enum sp2 = constructor.newInstance();
		System.out.println(sp2.hashCode());
	}
}


