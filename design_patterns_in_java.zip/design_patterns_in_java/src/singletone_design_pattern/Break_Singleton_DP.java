package singletone_design_pattern;

import java.lang.reflect.Constructor;

/* 1)We can break Simgletone DP using reflection API
   using reflection API's we can dynamically access, or change properties at runtime
   => Sol 1=> If objet is there throw runtime exception from inside constructor
   => sol2: Use Enam
   
   2) We can break it using deserialization
   => Override readResolve() method
*/
public class Break_Singleton_DP {
	
	private static Break_Singleton_DP s;
	
	private Break_Singleton_DP() {
		
	}
	
	public static  Break_Singleton_DP getInstnce() {
		if(s==null)
			synchronized(Break_Singleton_DP.class)
			{
				if(s==null) {
					s = new Break_Singleton_DP();
				}
			}
		{
			
		}
		return s;
		
	}

}



class Main1{
	public static void main(String[] args) throws Exception {
		
		Break_Singleton_DP sp1 = Break_Singleton_DP.getInstnce();
		System.out.println(sp1.hashCode());
		
		Constructor<Break_Singleton_DP> constructor = Break_Singleton_DP.class.getDeclaredConstructor();
		constructor.setAccessible(true);  // here we are modifying dynamically
		Break_Singleton_DP sp2 = constructor.newInstance();
		System.out.println(sp2.hashCode());
	}
}

