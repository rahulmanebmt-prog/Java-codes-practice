package singletone_design_pattern;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Brk_SnglT_Desirialization implements Serializable{
	
	private static Brk_SnglT_Desirialization s;
	
	private Brk_SnglT_Desirialization() {
		
	}
	
	public static Brk_SnglT_Desirialization getInstance() {
		if(s==null)
		{
			s = new Brk_SnglT_Desirialization();
		}
		return s;
	}

}


class BreakSingletoneUsingDeserialization{
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		
		Brk_SnglT_Desirialization ob1 =  Brk_SnglT_Desirialization.getInstance();
		System.out.println(ob1.hashCode());
		
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("abc.ob"));
		oos.writeObject(ob1);
		
		System.out.println("Serialization done....");
		
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("abc.ob"));
		Brk_SnglT_Desirialization ob2 = (Brk_SnglT_Desirialization) ois.readObject();
		System.out.println(ob2.hashCode());
		
		
	}
}
