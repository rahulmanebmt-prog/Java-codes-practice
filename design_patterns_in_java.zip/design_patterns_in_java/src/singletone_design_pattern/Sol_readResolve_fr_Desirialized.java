package singletone_design_pattern;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Sol_readResolve_fr_Desirialized implements Serializable{
	
private static Sol_readResolve_fr_Desirialized s;
	
	private Sol_readResolve_fr_Desirialized() {
		
	}
	
	public static Sol_readResolve_fr_Desirialized getInstance() {
		if(s==null)
		{
			s = new Sol_readResolve_fr_Desirialized();
		}
		return s;
	}
	
	

	 // ✅ THIS METHOD PREVENTS SINGLETON BREAKING
	    protected Object readResolve() {
	        return getInstance();
	    }


}


class Solution_Fr_Desirialized_readResolver{
	
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		
		Sol_readResolve_fr_Desirialized ob1 =  Sol_readResolve_fr_Desirialized.getInstance();
		System.out.println(ob1.hashCode());
		
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("abc.ob"));
		oos.writeObject(ob1);
		
		System.out.println("Serialization done....");
		
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("abc.ob"));
		Sol_readResolve_fr_Desirialized ob2 = (Sol_readResolve_fr_Desirialized) ois.readObject();
		System.out.println(ob2.hashCode());
		
		
	}
}