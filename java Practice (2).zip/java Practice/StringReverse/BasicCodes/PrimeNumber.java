package StringReverse.BasicCodes;

import java.util.Scanner;

public class PrimeNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number: ");
        int num = sc.nextInt();

        if(isPrime(num))
        {
            System.out.println("Number: "+num+" is Prime Number");
        }
        else{
            System.out.println("Number: "+num+" is 'Not' a Prime Number");
        }
    }

    public static boolean isPrime(int n){
        if(n<=1) 
        return false;
        for(int i=2; i<n; i++)
        {
            if(n%i == 0)
            return false;
        }
        return true;
        }
}
